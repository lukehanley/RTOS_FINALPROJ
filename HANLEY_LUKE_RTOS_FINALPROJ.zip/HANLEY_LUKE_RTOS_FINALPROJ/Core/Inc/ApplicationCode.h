/*
 * ApplicationCode.h
 *
 *  Created on: March 15, 2024
 *      Author: Luke Hanley
 */

#ifndef INC_APPLICATIONCODE_H_
#define INC_APPLICATIONCODE_H_

#include "LCD_Driver.h"
#include "Gyro_Driver.h"
#include "cmsis_os.h"


//funcs
void ApplicationInit(void);
void RunDemoForLCD(void);
void thread_init(void);
void timer_init(void);
void semaphore_init(void);
void flags_init(void);
void mutex_init(void);
void pressholdcb(void);
void directioncb(void);
void gyroTask(void * argument);
void physicsTask(void * argument);
void quantumTask(void * argument);
void LCDTask(void * argument);
void LEDTask(void * argument);
void obstacleTask(void * argument);
void drawMaze(void);

//data structures


struct BallStuff {
	uint16_t xpos;
	uint16_t ypos;
	float xvel;
	float yvel;
	int8_t xacc;
	int8_t yacc;
};

struct Cell {
	uint16_t xpos;
	uint16_t ypos;
	uint8_t north, south, east, west;		//zero is no wall, 1 is wall

};


//defines
#define USER_BUTTON_PORT		GPIOA
#define USER_BUTTON_PIN			GPIO_PIN_0

#define LED_RED_PORT			GPIOG
#define LED_GREEN_PORT 			GPIOG

#define LED_RED_PIN				GPIO_PIN_14
#define LED_GREEN_PIN 			GPIO_PIN_13

#define BTN_EVENT_FLAG			0b01
#define DIR_EVENT_FLAG			0b10
#define ALL_EVENT_FLAG1			0b11

#define LED0_EVENT_FLAG			0b001
#define LED1_EVENT_FLAG			0b010
#define NONE_EVENT_FLAG			0b100
#define ALL_EVENT_FLAG2			0b111


#endif /* INC_APPLICATIONCODE_H_ */
