/*
 * ApplicationCode.c
 *
 *  Created on: Mar 13, 2024
 *      Author: Luke Hanley (the steezmaster)
 */

#include "ApplicationCode.h"
#include <stdlib.h>


//----------- GLOBAL VARS ---------------
static uint8_t pressORhold;
static uint8_t samedirection;
static osTimerId_t speedtimerID;
static osTimerId_t dirtimerID;
static osMutexId_t ballmutex;
static osMutexId_t mazemutex;


static uint32_t angles;
static float xangle;
static float yangle;

static struct BallStuff BallStuffGlobal;
static struct Cell maze[48];

// --------- Vars with Mutex ------


/*

██╗███╗   ██╗██╗████████╗██╗ █████╗ ██╗     ██╗███████╗ █████╗ ████████╗██╗ ██████╗ ███╗   ██╗
██║████╗  ██║██║╚══██╔══╝██║██╔══██╗██║     ██║╚══███╔╝██╔══██╗╚══██╔══╝██║██╔═══██╗████╗  ██║
██║██╔██╗ ██║██║   ██║   ██║███████║██║     ██║  ███╔╝ ███████║   ██║   ██║██║   ██║██╔██╗ ██║
██║██║╚██╗██║██║   ██║   ██║██╔══██║██║     ██║ ███╔╝  ██╔══██║   ██║   ██║██║   ██║██║╚██╗██║
██║██║ ╚████║██║   ██║   ██║██║  ██║███████╗██║███████╗██║  ██║   ██║   ██║╚██████╔╝██║ ╚████║
╚═╝╚═╝  ╚═══╝╚═╝   ╚═╝   ╚═╝╚═╝  ╚═╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝

*/


/*
 * @brief Initalizes everything.
 *
 * @details Initializes LCD and gyro, then our threds and task communication structures. Lastly enables interrupts.
 */
void ApplicationInit(void)
{
	LTCD__Init();
    LTCD_Layer_Init(0);
    Gyro_Init();


    thread_init();
    timer_init();
    mutex_init();

    HAL_NVIC_EnableIRQ(EXTI0_IRQn);
    HAL_NVIC_SetPriority(EXTI0_IRQn, 13, 0);
}



/*
 * @brief Initializs sempahore
 */


/*
 * @brief Initializs flags
 */


/*
 * @brief Initializs mutexes
 */
void mutex_init(void) {
	ballmutex = osMutexNew(NULL);
	if(ballmutex == NULL) {
		while(1);
	}
	mazemutex = osMutexNew(NULL);
	if(ballmutex == NULL) {
		while(1);
	}
}

/*
 * @brief Initializes threads
 *
 * @details Initializes five threads each with stack size of 512.
 */
void thread_init(void) {

	// Gyro Task
	static StaticTask_t GyroAngle;
	static uint32_t gyrostack[256];
	static osThreadId_t gyroID;
	static const osThreadAttr_t gyroAtt = {
			.name = "gy",
			.cb_mem = &GyroAngle,
			.cb_size = sizeof(GyroAngle),
			.stack_mem = &gyrostack,
			.stack_size = sizeof(gyrostack),
			.priority = osPriorityNormal,
	};

	gyroID = osThreadNew(gyroTask, NULL, &gyroAtt);


	// Physics Engine Task
	static StaticTask_t PhysicsEngine;
	static uint32_t physstack[1024];
	static osThreadId_t physicsID;
	static const osThreadAttr_t physAtt = {
			.name = "physicsyurr",
			.cb_mem = &PhysicsEngine,
			.cb_size = sizeof(PhysicsEngine),
			.stack_mem = &physstack,
			.stack_size = sizeof(physstack),
			.priority = osPriorityNormal,
	};

	physicsID = osThreadNew(physicsTask, NULL, &physAtt);

	// Quantum Phaser Task
	static StaticTask_t QuantumPhaser;
	static uint32_t quantumstack[512];
	static osThreadId_t quantumID;
	static const osThreadAttr_t quantumAtt = {
			.name = "quantumbutton",
			.cb_mem = &QuantumPhaser,
			.cb_size = sizeof(QuantumPhaser),
			.stack_mem = &quantumstack,
			.stack_size = sizeof(quantumstack),
			.priority = osPriorityNormal,
	};

	quantumID = osThreadNew(quantumTask, NULL, &quantumAtt);

	// LCD Display Task
	static StaticTask_t LCDdisplay;
	static uint32_t LCDstack[1024];
	static osThreadId_t LCDID;
	static const osThreadAttr_t LCDAtt = {
			.name = "LCD",
			.cb_mem = &LCDdisplay,
			.cb_size = sizeof(LCDdisplay),
			.stack_mem = &LCDstack,
			.stack_size = sizeof(LCDstack),
			.priority = osPriorityNormal,
	};

	LCDID = osThreadNew(LCDTask, NULL, &LCDAtt);


	// LED Output Task
	static StaticTask_t LEDoutput;
	static uint32_t ledStack[512];
	static osThreadId_t LEDID;
	static const osThreadAttr_t LEDAtt = {
			.name = "LED",
			.cb_mem = &LEDoutput,
			.cb_size = sizeof(LEDoutput),
			.stack_mem = &ledStack,
			.stack_size = sizeof(ledStack),
			.priority = osPriorityNormal,
	};

	LEDID = osThreadNew(LEDTask, NULL, &LEDAtt);

	// Obstacle Output Task
	static StaticTask_t Obstacles;
	static uint32_t obstaclestack[512];
	static osThreadId_t obstacleID;
	static const osThreadAttr_t obstacleAtt = {
			.name = "Obstacle",
			.cb_mem = &Obstacles,
			.cb_size = sizeof(Obstacles),
			.stack_mem = &obstaclestack,
			.stack_size = sizeof(obstaclestack),
			.priority = osPriorityNormal,
	};

	obstacleID = osThreadNew(obstacleTask, NULL, &obstacleAtt);
}

/*
 * @brief Initializes timers
 *
 * @details Initializes two one shot timers so we can tell how long we have been turning or buttons have been pressed.
 */
void timer_init(void) {

	// Timer for Speed Task
	static StaticTimer_t speedtimerTCB;
	static const osTimerAttr_t speedAtt = {
			.name = "iamspeed",
			.cb_mem = &speedtimerTCB,
			.cb_size =  sizeof(speedtimerTCB),
	};
	speedtimerID = osTimerNew(pressholdcb, osTimerOnce, NULL, &speedAtt);
	while(speedtimerID == NULL) {};


	// Timer for Direction Task
	static StaticTimer_t dirtimerTCB;
	static const osTimerAttr_t dirtimerAtt = {
			.name = "iamdirection",
			.cb_mem = &dirtimerTCB,
			.cb_size =  sizeof(dirtimerTCB),
	};
	dirtimerID = osTimerNew(directioncb, osTimerOnce, NULL, &dirtimerAtt);
	while(dirtimerID == NULL) {};
}





void drawMaze(void) {
	for(int i = 0; i < 48; i++) {
		int x = maze[i].xpos;
		int y = maze[i].ypos;
		if(maze[i].north) {
			LCD_Draw_Horizontal_Line(x - 20, y - 20, 40, LCD_COLOR_RED);
		}
		if(maze[i].east) {
			LCD_Draw_Vertical_Line(x + 20, y - 20, 40, LCD_COLOR_RED);
		}
		if(maze[i].south) {
			LCD_Draw_Horizontal_Line(x - 20, y + 20, 40, LCD_COLOR_RED);
		}
		if(maze[i].west) {
			LCD_Draw_Vertical_Line(x-+ 20, y - 20, 40, LCD_COLOR_RED);
		}

	}
}

/*

████████╗██╗███╗   ███╗███████╗██████╗     ███████╗██╗   ██╗███╗   ██╗ ██████╗███████╗
╚══██╔══╝██║████╗ ████║██╔════╝██╔══██╗    ██╔════╝██║   ██║████╗  ██║██╔════╝██╔════╝
   ██║   ██║██╔████╔██║█████╗  ██████╔╝    █████╗  ██║   ██║██╔██╗ ██║██║     ███████╗
   ██║   ██║██║╚██╔╝██║██╔══╝  ██╔══██╗    ██╔══╝  ██║   ██║██║╚██╗██║██║     ╚════██║
   ██║   ██║██║ ╚═╝ ██║███████╗██║  ██║    ██║     ╚██████╔╝██║ ╚████║╚██████╗███████║
   ╚═╝   ╚═╝╚═╝     ╚═╝╚══════╝╚═╝  ╚═╝    ╚═╝      ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚══════╝

*/


/*
 * @brief Callback for button press timer
 *
 * @details If we enter callback we set global var to 1
 */
void pressholdcb(void) {
	pressORhold = 1;
}

/*
 * @brief Callback for direction timer
 *
 * @details If we enter callback we set global var to 1
 */
void directioncb(void) {
	samedirection = 1;
}

/*

 ████████╗ █████╗ ███████╗██╗  ██╗███████╗
╚══██╔══╝██╔══██╗██╔════╝██║ ██╔╝██╔════╝
   ██║   ███████║███████╗█████╔╝ ███████╗
   ██║   ██╔══██║╚════██║██╔═██╗ ╚════██║
   ██║   ██║  ██║███████║██║  ██╗███████║
   ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝

*/

/*
 * @brief Updates the speed of the vehicle
 *
 * @details Waits for semaphore from button press, starts timer, waits for second acquire, meaning the button has been released. If we held for more than
 * 1 second then we know to decrement, else we simply increment.
 */

void gyroTask(void * argument) {
	int16_t yvel, xvel;
	float sens = 0.001;
	xangle = 0;
	yangle = 0;

	while(1) {
		osDelay(100);
		yvel = Gyro_Get_Velocity_Y();
		xvel = Gyro_Get_Velocity_X();

		yangle += yvel * sens;
		xangle += xvel * sens;

		//angles = (yangle << 16) | xangle;
	}


}

void physicsTask(void * argument) {
	int32_t both = 0;
	osStatus_t status;
	uint8_t drifter = 0;

	// initallize ball to zero, grid is 320 x 240
	status = osMutexAcquire(ballmutex, osWaitForever);
	BallStuffGlobal.xacc = 0;
	BallStuffGlobal.xvel = 0;
	BallStuffGlobal.xpos = 20;
	BallStuffGlobal.yacc = 0;
	BallStuffGlobal.yvel = 0;
	BallStuffGlobal.ypos = 20;
	status = osMutexRelease(ballmutex);

	while(1) {
		osDelay(100);
//		both = angles;		//atomic single line grab

//		xangle = both;
//		yangle = both >> 16;

//		xangle = both >> 16;
//		yangle = both;
		float xpos_f, ypos_f = 0;
		status = osMutexAcquire(ballmutex, osWaitForever);

		//account for drift
		drifter++;
		if(drifter >= 20) {
			xangle++;
			drifter = 0;
		}

		BallStuffGlobal.xvel = xangle;
		BallStuffGlobal.yvel = yangle;



        xpos_f =  BallStuffGlobal.xvel / 10;
        ypos_f = BallStuffGlobal.yvel / 10;

        BallStuffGlobal.xpos += round(xpos_f);
        BallStuffGlobal.ypos += round(ypos_f);

        if(BallStuffGlobal.xpos <= 5){
            BallStuffGlobal.xpos = 5;
        }
        else if(BallStuffGlobal.xpos >= 315){
        	BallStuffGlobal.xpos = 315;
        }

        if(BallStuffGlobal.ypos <= 5){
        	BallStuffGlobal.ypos = 5;
        }
        else if(BallStuffGlobal.ypos >= 235){
        	BallStuffGlobal.ypos = 235;
        }

		status = osMutexRelease(ballmutex);
	}
}

void quantumTask(void * argument) {
	while(1) {
		osDelay(1000);
	}
}

void LCDTask(void * argument) {
	osStatus_t status;

	LCD_SetTextColor(LCD_COLOR_RED);
	LCD_SetFont(&Font16x24);
	LCD_Clear(0, LCD_COLOR_WHITE);

//	uint16_t oldx, oldy;

	while(1) {
		osDelay(20);

		status = osMutexAcquire(ballmutex, osWaitForever);
		LCD_Clear(0, LCD_COLOR_WHITE);
		LCD_Draw_Circle_Fill(BallStuffGlobal.ypos, BallStuffGlobal.xpos, 5, LCD_COLOR_GREEN);
		status = osMutexRelease(ballmutex);
		status = osMutexAcquire(mazemutex, osWaitForever);
		drawMaze();
		status = osMutexRelease(mazemutex);
//		oldx = BallStuffGlobal.xpos;
//		oldy = BallStuffGlobal.ypos;
	}
}

void LEDTask(void * argument) {
	while(1) {
		osDelay(1000);
	}
}

void obstacleTask(void * argument) {
	//create maze
	osStatus_t status;

	status = osMutexAcquire(mazemutex, osWaitForever);

	int k = 0;
	for(int i = 1; i < 9; i++) {		//y
		for(int j = 1; j < 7; j++) {	//x

			maze[k].xpos = j * 40;
			maze[k].xpos -= 20;

			maze[k].ypos = i * 40;
			maze[k].ypos -= 20;


			uint8_t rando = rand();
			rando = rando % 5;


			//walls
			if(rando  == 0) {
				maze[k].east = 1;
				maze[k].north = 1;
				maze[k].south = 0;
				maze[k].west = 0;
			}
			if(rando  == 1) {
				maze[k].east = 0;
				maze[k].north = 1;
				maze[k].south = 0;
				maze[k].west = 0;
			}
			if(rando  == 2) {
				maze[k].east = 0;
				maze[k].north = 0;
				maze[k].south = 1;
				maze[k].west = 1;
			}
			if(rando  == 3) {
				maze[k].east = 0;
				maze[k].north = 1;
				maze[k].south = 1;
				maze[k].west = 0;
			}
			if(rando  == 3) {
				maze[k].east = 0;
				maze[k].north = 0;
				maze[k].south = 0;
				maze[k].west = 0;
			}


			k++;
		}
	}
	status = osMutexRelease(mazemutex);

	while(1) {
		osDelay(1000);
	}
}

/*

██╗███╗   ██╗████████╗███████╗██████╗ ██████╗ ██╗   ██╗██████╗ ████████╗███████╗
██║████╗  ██║╚══██╔══╝██╔════╝██╔══██╗██╔══██╗██║   ██║██╔══██╗╚══██╔══╝██╔════╝
██║██╔██╗ ██║   ██║   █████╗  ██████╔╝██████╔╝██║   ██║██████╔╝   ██║   ███████╗
██║██║╚██╗██║   ██║   ██╔══╝  ██╔══██╗██╔══██╗██║   ██║██╔═══╝    ██║   ╚════██║
██║██║ ╚████║   ██║   ███████╗██║  ██║██║  ██║╚██████╔╝██║        ██║   ███████║
╚═╝╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝        ╚═╝   ╚══════╝

*/
/*
 * @brief Handles button interrupts
 *
 * @details Posts semaphore upon button press or release
 */
void EXTI0_IRQHandler(){
	HAL_NVIC_DisableIRQ(EXTI0_IRQn);


	__HAL_GPIO_EXTI_CLEAR_FLAG(USER_BUTTON_PIN);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}
